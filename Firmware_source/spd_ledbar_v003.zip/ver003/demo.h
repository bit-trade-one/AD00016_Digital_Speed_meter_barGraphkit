extern unsigned char op_demo(unsigned int,char);

#define OPENING_DEMO_SIZE	64
#define OPENING_DEMO_SIZE2	80

